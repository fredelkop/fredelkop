public class myLinkedList {
    Node head;
    Node tail;
    int size;

    public myLinkedList() {
        this.head = null;
        this.tail = null;
        this.size = 0;
    }

    public void add(int data) {
        Node newNode = new Node(data);

        if (this.head == null) {
            this.head = newNode;
            this.tail = newNode;
        } else {
            this.tail.nextNode = newNode;
            this.tail = newNode;
        }

        this.size++;
    }

    public boolean hasCycle(Node head) {
        if (head == null || head.nextNode == null) {
            return false;
        }

        Node slow = head;
        Node fast = head.nextNode;

        while (slow != fast) {
            if (fast == null || fast.nextNode == null) {
                return false;
            }
            slow = slow.nextNode;
            fast = fast.nextNode.nextNode;
        }

        return true;
    }

    public Node delete(int data) {
        if (this.head == null) {
            return null;
        }

        Node current = this.head;
        Node prev = null;

        if (current.number == data) {
            this.head = current.nextNode;
            this.size--;
            return current;
        }

        while (current != null && current.number != data) {
            prev = current;
            current = current.nextNode;
        }

        if (current == null) {
            return null;
        }

        if (current == this.tail) {
            this.tail = prev;
        }

        prev.nextNode = current.nextNode;
        this.size--;
        return current;
    }

    public Node findNodeBefore(int data) {
        if (this.head == null) {
            return null;
        }

        Node current = this.head;

        while (current != null && current.nextNode != null && current.nextNode.number != data) {
            current = current.nextNode;
        }

        if (current == null || current.nextNode == null) {
            return null;
        }

        return current;
    }

    public Node find(int data) {
        if (this.head == null) {
            return null;
        }

        Node current = this.head;

        while (current != null) {
            if (current.number == data) {
                return current;
            }
            current = current.nextNode;
        }

        return null;
    }

    public void traverse() {
        Node current = this.head;

        while (current != null) {
            System.out.print(current.toString() + " -> ");
            current = current.nextNode;
        }

        System.out.println("null");
    }
}