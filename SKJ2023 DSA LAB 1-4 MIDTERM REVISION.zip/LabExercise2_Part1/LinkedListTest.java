public class LinkedListTest {
    public static void main(String[] args) {
        myLinkedList linkedList = new myLinkedList();

        // Testing add
        linkedList.add(1);
        linkedList.add(2);
        linkedList.add(3);
        linkedList.add(4);
        linkedList.add(5);

        // Testing hasCycle
        System.out.println("Linked list has cycle: " + linkedList.hasCycle(linkedList.head));

        // Testing delete
        System.out.println("Deleted node: " + linkedList.delete(3).toString());
        System.out.println("Linked list after deleting 3: ");
        linkedList.traverse();

        // Testing findNodeBefore
        System.out.println("Node before 2: " + linkedList.findNodeBefore(2).toString());

        // Testing find
        System.out.println("Found node with value 4: " + linkedList.find(4).toString());
    }
}