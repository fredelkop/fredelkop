public class Node {
    int number;
    Node nextNode;

    public Node(int number) {
        this.number = number;
        this.nextNode = null;
    }

    public Node() {
        this.nextNode = null;
    }

    public String toString(){
        return " " + number;
    }
}