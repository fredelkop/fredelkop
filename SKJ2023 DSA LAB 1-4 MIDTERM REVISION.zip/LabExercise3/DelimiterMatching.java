import java.util.Scanner;
import java.util.Stack;

public class DelimiterMatching {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the expression: ");
        String expression = scanner.nextLine();

        delimiterMatching(expression);
    }

    public static void delimiterMatching(String expression) {
        Stack<Integer> stack = new Stack<>();
        for (int i = 0; i < expression.length(); i++) {
            if (expression.charAt(i) == '(') {
                stack.push(i);
            } else if (expression.charAt(i) == ')') {
                if (stack.isEmpty()) {
                    System.out.println("Error: Missing an opening delimiter at position " + (i + 1));
                    return;
                }
                int start = stack.pop();
                System.out.println(expression.substring(start, i + 1));
            }
            else if (expression.charAt(i) == '{') {
                stack.push(i);
            } else if (expression.charAt(i) == '}') {
                if (stack.isEmpty()) {
                    System.out.println("Error: Missing an opening delimiter at position " + (i + 1));
                    return;
                }
                int start = stack.pop();
                System.out.println(expression.substring(start, i + 1));
            }
            else if (expression.charAt(i) == '[') {
                stack.push(i);
            } else if (expression.charAt(i) == ']') {
                if (stack.isEmpty()) {
                    System.out.println("Error: Missing an opening delimiter at position " + (i + 1));
                    return;
                }
                int start = stack.pop();
                System.out.println(expression.substring(start, i + 1));
            }
        }

        while (!stack.isEmpty()) {
            int position = stack.pop() + 1;
            System.out.println("Error: Missing a closing delimiter at position " + position);
        }
    }
}
