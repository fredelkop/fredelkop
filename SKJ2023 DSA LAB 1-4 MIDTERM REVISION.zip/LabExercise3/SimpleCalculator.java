import java.util.Scanner;
import java.util.Stack;

public class SimpleCalculator {

    public static int evaluateExpression(String expression) {
        Stack<Integer> numbers = new Stack<>();
        Stack<Character> operators = new Stack<>();

        // Iterate through each character in the expression
        for (int i = 0; i < expression.length(); i++) {
            char ch = expression.charAt(i);

            // Skip whitespace (error handling)
            if (ch == ' ') {
                continue;
            }

            // If the character is a digit, parse the entire number
            if (Character.isDigit(ch)) {
                int num = 0;
                while (i < expression.length() && Character.isDigit(expression.charAt(i))) {
                    num = num * 10 + (expression.charAt(i) - '0');
                    i++;
                }
                i--; // Move the index back one step
                numbers.push(num);
            } else if (ch == '+' || ch == '-') {
                // If the character is an operator, push it onto the operator stack
                while (!operators.isEmpty() && (operators.peek() == '+' || operators.peek() == '-')) {
                    processOperation(numbers, operators);
                }
                operators.push(ch);
            }
        }

        // Process any remaining operators
        while (!operators.isEmpty()) {
            processOperation(numbers, operators);
        }

        // The result is the only element left on the numbers stack
        return numbers.pop();
    }

    private static void processOperation(Stack<Integer> numbers, Stack<Character> operators) {
        int num2 = numbers.pop();
        int num1 = numbers.pop();
        char operator = operators.pop();

        if (operator == '+') {
            numbers.push(num1 + num2);
        } else if (operator == '-') {
            numbers.push(num1 - num2);
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a simple expression (only + and - operators, no parentheses): ");
        String expression = scanner.nextLine();

        // Evaluate the expression
        int result = evaluateExpression(expression);
        System.out.println("Result: " + result);

        scanner.close();
    }
}