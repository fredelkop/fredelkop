import java.util.LinkedList;
import java.util.Scanner;

public class PalindromeChecker2 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a string: ");
        String input = scanner.nextLine();
        System.out.println("Is the string a palindrome? " + isPalindrome(input));
    }

    public static boolean isPalindrome(String str) {
        LinkedList<Character> stack = new LinkedList<>();

        for (char c : str.toCharArray()) {
            stack.push(c);
        }

        while (stack.size() > 1) {
            if (stack.pop() != stack.removeLast()) {
                return false;
            }
        }

        return true;
    }
}
