public class Main {

    public static void main(String[] args) {

        // Initialization
        int[] loopValues = {100, 500, 1000, 5000, 10000, 50000, 100000};
        double[] timesA = new double[loopValues.length];
        double[] timesB = new double[loopValues.length];

        // Measure the time taken for each loop
        for (int i = 0; i < loopValues.length; i++) {
            int n = loopValues[i];

            // Loop A
            long startTimeA = System.nanoTime();
            int sumA = 0;
            for (int j = 1; j <= n; j++) {
                for (int k = 1; k <= 10000; k++) {
                    sumA += k;
                }
            }
            long endTimeA = System.nanoTime();
            timesA[i] = (endTimeA - startTimeA) / 1000000.0; // convert to milliseconds

            // Loop B
            long startTimeB = System.nanoTime();
            int sumB = 0;
            for (int j = 1; j <= n; j++) {
                for (int k = 1; k <= n; k++) {
                    sumB += k;
                }
            }
            long endTimeB = System.nanoTime();
            timesB[i] = (endTimeB - startTimeB) / 1000000.0; // convert to milliseconds
        }

        // Find the loop value for which Loop B is faster
        int loopValueForB = loopValues[0];
        for (int i = 1; i < loopValues.length; i++) {
            if (timesB[i] < timesA[i]) {
                loopValueForB = loopValues[i];
                break;
            }
        }

        // Print the result
        System.out.println("Loop B is faster for n = " + loopValueForB);
    }
}