import java.util.Date;

public class Sum {
    public static void main(String[] args) {
        long startTime, endTime;
        int n = 1000;

        // Algorithm A
        startTime = new Date().getTime();
        int sumA = 0;
        for (int i = 1; i <= n; i++) {
            sumA = sumA + i;
        }
        endTime = new Date().getTime();
        System.out.println("Algorithm A took " + (endTime - startTime) + " milliseconds");

        // Algorithm B
        startTime = new Date().getTime();
        int sumB = 0;
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= i; j++) {
                sumB = sumB + 1;
            }
        }
        endTime = new Date().getTime();
        System.out.println("Algorithm B took " + (endTime - startTime) + " milliseconds");

        // Algorithm C
        startTime = new Date().getTime();
        int sumC = n * (n + 1) / 2;
        endTime = new Date().getTime();
        System.out.println("Algorithm C took " + (endTime - startTime) + " milliseconds");
    }
}