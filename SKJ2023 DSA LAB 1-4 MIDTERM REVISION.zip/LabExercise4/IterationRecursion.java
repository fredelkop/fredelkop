public class IterationRecursion {

    public static void main(String[] args) {
        printHi(3);
    }

    public static void printHi(int n) {
        if (n <= 0) {
            return;
        }
        printHi(n - 1);
        System.out.println("Hi");
    }
}