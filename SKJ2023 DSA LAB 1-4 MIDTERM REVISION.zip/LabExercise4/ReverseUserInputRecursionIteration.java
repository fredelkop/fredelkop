import java.util.Scanner;

class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

public class ReverseUserInputRecursionIteration {
    static Node head = null;

    static Node addToTheLast(Node node) {
        if (head == null) {
            head = node;
        } else {
            Node temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = node;
        }
        return head;
    }

    static void printList() {
        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }

    static Node reverse(Node node) {
        Node prev = null;
        Node current = node;
        Node next = null;
        while (current != null) {
            next = current.next;
            current.next = prev;
            prev = current;
            current = next;
        }
        node = prev;
        return node;
    }

    static void reverseIterative(Node node) {
        Node prev = null;
        Node current = node;
        Node next = null;
        while (current != null) {
            next = current.next;
            current.next = prev;
            prev = current;
            current = next;
        }
        head = prev;
    }

   public static void main(String[] args) {
      Scanner scanner = new Scanner(System.in);
      System.out.println("Enter the number of elements (size): ");
       int n = scanner.nextInt();
       System.out.println("Enter the elements (one line, separated with spaces ' '): ");
      for (int i = 0; i < n; i++) {
        head = addToTheLast(new Node(scanner.nextInt()));
        }
      System.out.println("Original List: ");
      printList();

    // Using recursion
      head = reverse(head);
      System.out.println("Reversed List using recursion: ");
      printList();

    // Using iteration
      reverseIterative(head);
      System.out.println("Reversed List using iteration: ");
      printList();
   }
}