import java.util.Scanner;
import java.util.Stack;

public class ReverseStackRecursionIteration {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Stack<Integer> stack = new Stack<>();
        System.out.println("Enter the size of the stack:");
        int size = scanner.nextInt();
        System.out.println("Enter the elements of the stack:");
        for (int i = 0; i < size; i++) {
            stack.push(scanner.nextInt());
        }
        System.out.println("The original stack is: " + stack);

        // Reverse the stack using recursion
        System.out.println("Reversing the stack using recursion:");
        reverseStackUsingRecursion(stack);
        System.out.println("The reversed stack using recursion is: " + stack);

        // Reverse the stack using iteration
        System.out.println("Reversing the stack using iteration:");
        reverseStackUsingIteration(stack);
        System.out.println("The reversed stack using iteration is: " + stack);
    }

    private static void reverseStackUsingRecursion(Stack<Integer> stack) {
        if (!stack.isEmpty()) {
            int top = stack.pop();
            reverseStackUsingRecursion(stack);
            insertAtBottom(stack, top);
        }
    }

    private static void insertAtBottom(Stack<Integer> stack, int item) {
        if (stack.isEmpty()) {
            stack.push(item);
        } else {
            int top = stack.pop();
            insertAtBottom(stack, item);
            stack.push(top);
        }
    }

    private static void reverseStackUsingIteration(Stack<Integer> stack) {
        if (!stack.isEmpty()) {
            Stack<Integer> tempStack = new Stack<>();
            while (!stack.isEmpty()) {
                tempStack.push(stack.pop());
            }
            while (!tempStack.isEmpty()) {
                stack.push(tempStack.pop());
            }
        }
    }
}