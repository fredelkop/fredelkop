public class RecursionTutorial {
    public static void main(String[] args) {
        sayHi(3);
    }

    private static void sayHi(int count) {
        if (count == 0) {
            return;
        }
        System.out.println("Hi!");
        sayHi(count - 1);
    }
}
