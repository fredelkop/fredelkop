import java.util.Scanner;

public class PrintSumChoice {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the size of the array:");
        int n = scanner.nextInt();
        System.out.println("Enter the array elements:");
        int[] arr = new int[n];
        for (int i = 0; i < n; i++) {
            arr[i] = scanner.nextInt();
        }
        System.out.println("Choose the method to calculate the sum (1-Recursion, 2-Iteration):");
        int choice = scanner.nextInt();
        scanner.close();

        if (choice == 1) {
            System.out.println("The sum of the array elements using recursion is: " + printSumRecursion(arr, arr.length - 1));
        } else if (choice == 2) {
            System.out.println("The sum of the array elements using iteration is: " + printSumIteration(arr));
        } else {
            System.out.println("Invalid choice. Please run the program again and choose a valid method.");
        }
    }

    private static int printSumRecursion(int[] arr, int n) {
        if (n == 0) {
            return arr[n];
        } else {
            return arr[n] + printSumRecursion(arr, n - 1);
        }
    }

    private static int printSumIteration(int[] arr) {
        int sum = 0;
        for (int i = 0; i < arr.length; i++) {
            sum += arr[i];
        }
        return sum;
    }
}