import java.util.LinkedList;

public class LinkedListExample {

    public static void main(String[] args) {
        LinkedList<Integer> MyList = new LinkedList<>();

        // Adding elements to MyList
        MyList.add(100);
        MyList.add(200);
        MyList.add(300);
        MyList.add(400);
        MyList.add(500);
        MyList.add(600);

        // Printing the first element of MyList
        System.out.println("First element of MyList: " + MyList.getFirst());

        // Printing the last element of MyList
        System.out.println("Last element of MyList: " + MyList.getLast());

        // Adding 50 as the first element of the MyList and printing MyList
        MyList.addFirst(50);
        System.out.println("MyList after adding 50 to the start: " + MyList);

        // Adding 700 as the last element of the MyList and printing MyList
        MyList.addLast(700);
        System.out.println("MyList after adding 700 to the end: " + MyList);

        // Updating MyList by setting the value of 200 to 150 and printing MyList
        MyList.set(MyList.indexOf(200), 150);
        System.out.println("MyList after updating 200 to 150: " + MyList);

        // Deleting 300 and 400 from MyList using clear() and printing MyList
         MyList.subList(MyList.indexOf(300), MyList.indexOf(400) + 1).clear();
        System.out.println("MyList after deleting 300 and 400: " + MyList);
    }
}