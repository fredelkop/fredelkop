import java.util.LinkedList;
import java.util.Scanner;

class PhoneBookEntry {
    String name;
    String phoneNumber;

    PhoneBookEntry(String name, String phoneNumber) {
        this.name = name;
        this.phoneNumber = phoneNumber;
    }

    public String toString() {
        return "Name: " + name + ", Phone Number: " + phoneNumber;
    }
}

class PhoneBook {
    LinkedList<PhoneBookEntry> phoneBookEntries;

    PhoneBook() {
        phoneBookEntries = new LinkedList<>();
    }

    void insertEntry(String name, String phoneNumber) {
        phoneBookEntries.add(new PhoneBookEntry(name, phoneNumber));
    }

    void deleteEntry(String name) {
        phoneBookEntries.removeIf(entry -> entry.name.equals(name));
    }

void searchEntry(String name) {
    Scanner scanner = new Scanner(System.in); // Create a Scanner object
    PhoneBookEntry entry = phoneBookEntries.stream()
            .filter(phoneBookEntry -> phoneBookEntry.name.equals(name))
            .findFirst()
            .orElse(null);

    if (entry != null) {
        System.out.println(entry);
    } else {
        // If no record is found for the name, search for the phone number
        System.out.print("No record found for name: " + name + ". \nEnter phone number to search: ");
        String phoneNumberToSearch = scanner.next(); // Read the phone number input

        PhoneBookEntry phoneNumberEntry = phoneBookEntries.stream()
                .filter(phoneBookEntry -> phoneBookEntry.phoneNumber.equals(phoneNumberToSearch))
                .findFirst()
                .orElse(null);

        if (phoneNumberEntry != null) {
            System.out.println(phoneNumberEntry);
        } else {
            System.out.println("No record found for name: " + name + " and phone number: " + phoneNumberToSearch);
         }
      }
   }

    void printPhoneBook() {
        for (PhoneBookEntry entry : phoneBookEntries) {
            System.out.println(entry);
        }
    }

    void clearPhoneBook() {
        phoneBookEntries.clear();
    }
}

public class Main {
    public static void main(String[] args) {
        PhoneBook phoneBook = new PhoneBook();
        Scanner scanner = new Scanner(System.in);
        int choice;
        String name, phoneNumber;

        do {
            System.out.println("\nTelephone Directory");
            System.out.println("1. Insert a new entry");
            System.out.println("2. Delete an existing entry");
            System.out.println("3. Search for a specific entry");
            System.out.println("4. Print the entire phone list");
            System.out.println("5. Clear the entire directory");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter the name: ");
                    name = scanner.next();
                    System.out.print("Enter the phone number: ");
                    phoneNumber = scanner.next();
                    phoneBook.insertEntry(name, phoneNumber);
                    break;
                case 2:
                    System.out.print("Enter the name: ");
                    name = scanner.next();
                    phoneBook.deleteEntry(name);
                    break;
                case 3:
                    System.out.print("Enter the name: ");
                    name = scanner.next();
                    phoneBook.searchEntry(name);
                    break;
                case 4:
                    phoneBook.printPhoneBook();
                    break;
                case 5:
                    phoneBook.clearPhoneBook();
                    System.out.println("Deleting...");
                    break;
                case 6:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid choice.");
            }
        } while (choice != 6);

    }
}